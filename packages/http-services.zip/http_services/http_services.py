# standard-libray imports
import base64
import json
import re
# application-related imports
from app.settings import settings


class HttpServices(object):
    """An http service module that will prepare and execute http requests.

    version: 1.0.2

    This module currently supports APPENGINE projects ONLY.
    - Dependencies:
        - google.appengine.api
        - app.settings

    This http service handler can support any resource(s) defined on Settings.py.
    E.g: mbc, resource_directory, dialog_flow, etc. It assumes a general format
    for the resource:

    settings[{resource_name}]['api'][{resource_item}]
    settings[{resource_name}][{api_key}]
    settings["headers"] = [list of header namers]
    settings[{header_name_1}] = {header_value_1}
    ...
    settings[{header_name_n}] = {header_value_n}

    Notes:
        * Header names are case sensitive
        * For "Authorization" header, the class currently supports:
            - Basic
            - Bearer
            * For "Basic" Authorization (eg. ServiceNow) api calls, a username
            and password must be supplied on settings.py
            * For "Bearer" type (eg. DialogFlow) the "api_key" is used.
            * "Authorization" header must only contain as value:
                - "Bearer" or "Basic"
        * "api_key" is a required field, even if not used by your API.

    Attributes:
        request_type -- type of request (GET, POST, PUT, DELETE)
        headers -- an internal attribute used for executing the request
        resource -- the name of the resource defined in settings.py
        resource_item -- the name of the resource item defined in settings.py
        payload -- optional payload for POST requests
        params -- named params for targert url
        env -- environment url
    """
    supported_requests = ['GET', 'POST', 'PUT', 'DELETE']

    def __init__(self, request_type=None,payload=None):
        """Constructing httpServices attributes.

        The request_type supported for the services are:
            - GET
            - POST
            - DELETE
            - PUT

        For POST requests, a payload must be provided; otherwise an exception
        will be raised.

        If a request not supported is provided, an exeption will be raised
        """

        # making sure request_type is currently supported
        if request_type not in self.supported_requests:
            raise InvalidRequestTypeError("INVALID REQUEST TYPE. Request type {} "
                "is not supported. Please provide any of the following request "
                "types: {}".format(request_type, supported_requests))

        # checking if payload is missing for a POST request
        if request_type in ["POST", "PUT"] and payload is None:
            raise InvalidRequestError("INVALID REQUEST. A payload most be "
                "provided for a PUT and POST requests.")

        self.request_type = request_type
        self.payload = payload
        self._headers = None
        self.resource = None
        self.resource_item = None
        self._params = None
        self._target = None
        self._env = None

    def set_resource(self, resource):
        """Setting resource"""
        self.resource = resource
        self._env = settings[self.resource]['env']

    def set_resource_item(self, resource_item):
        """Setting resource item"""
        self.resource_item = resource_item

    def set_resource_headers(self):
        """Building headers for resource.

        Set the headers property for the http service object. It searches
        for the "headers" key in the settings.py resource object,
        and it uses its values to set the appropiate headers
        """
        try:
            resource_requirements = settings[self.resource]["headers"]
            final_headers = {}

            for requirement in resource_requirements:
                # setting up specific requirement for resource
                if requirement == "Authorization":
                    # setting up 'bearer' authorization
                    if settings[self.resource][requirement] == "Bearer":
                        final_headers[requirement] = (
                            settings[self.resource][requirement] + " " +
                            settings[self.resource]["api_key"])
                    # setting up 'basic' authorization
                    elif settings[self.resource][requirement] == "Basic":
                        # retriving credentials
                        auth_user = settings[self.resource]['username']
                        pwd = settings[self.resource]['password']

                        final_headers[requirement] = (
                            settings[self.resource][requirement] + " " +
                            base64.b64encode(auth_user + ':' + pwd))
                # adding the rest of the headers to object
                else:
                    final_headers[requirement] = (
                        settings[self.resource][requirement])
            self._headers = final_headers
        except KeyError as e:
            raise InvalidRequestError("INVALID REQUEST. Resource {} is missing "
                "a header key on settings.py for the requested "
                "resource. {}".format(self.resource,e))

    def set_params(self, **params):
        """Setting up the key-value pairs of named params on both the
        reource and resource items

        Args:
            params(dict/None): params is a dictionary of params to set or None.
        """
        if params:
            self._params.update(**params)
        else:
            # building initial params from resource and resource item
            final_params = {}
            resource_params = self.construct_params(self._env)
            # building resource_item params
            if settings[self.resource]['api'].get(self.resource_item):
                resource_item_params = self.construct_params(
                    settings[self.resource]['api'].get(self.resource_item))
                resource_params.update(resource_item_params)
            # setting up params
            self._params = resource_params

    def set_resource_target(self):
        """Building the target url for the http service.

        For named parems on either the rerouce and the resource_item.
        Only they named-params: 'resource_item' & 'api_key' will be set
        by default. For subsequent named-params you must call
        'add_target_params'
        """
        try:
            # fetching resource envrionment
            self._target = self._env
            basic_params = {}

            if settings[self.resource]['api'].get(self.resource_item):
                basic_params["resource_item"]=(
                    settings[self.resource]['api'].get(self.resource_item))

            if settings[self.resource].get("api_key"):
                basic_params["api_key"]=settings[self.resource].get("api_key")
            self.add_target_params(**basic_params)
        except KeyError as e:
            raise InvalidRequestError("INVALID REQUEST. Resource {} is missing "
                "a key on settings.py - {}".format(self.resource, e))

    def add_target_params(self, **args):
        """Adding extra named parameters to the target URL.

        By default "api_key" and "resource_item" are added to the target
        url. For any extra params such as "id", etc; use this function to
        add those parameters to target.

        Args:
            args(dict): A dictioray of named parameters to add to target url
        """
        try:
            # modifying params
            self.set_params(**args)
            # modifying url target with named params
            self._target = self._target.format(**self._params)
        except KeyError as e:
            raise InvalidRequestError("INVALID TARGET. Target {} is missing "
                "a key - {}".format(self._target, e))

    def get_target(self):
        """Getter for private property 'target'
        """
        return self._target

    def get_headers(self):
        """Getter for private property 'headers'
        """
        return self._headers

    def get_params(self):
        """Getter for private property 'params'
        """
        return self._params

    def get_env(self):
        """Getter for environment property"""
        return self._env

    def construct_params(self, const_from):
        """Constructing a dictionary of named parameters from a string.

        Args:
            cons_from(string): String to construct key-value pair of named
                               params from

        Returns:
            A dictionary of named params for the given string.
        """
        # const_from is for the form "{key_1}...{key2}"
        # so the first thing is to split the string by "{"
        pattern = re.compile(r"\{([A-Za-z0-9_]+)\}")
        clean_keys = pattern.findall(const_from)
        # now we have to clean the list of keys.
        # the following removes any non-alphanum characters
        # effectively cleaning the final keys
        return {key:"{%s}"%key for key in clean_keys}

    def execute_request(self):
        """Executing the real request!
        """
        try:
            try:
                # used for executing on google app engine
                from google.appengine.api import urlfetch
                # mapping method to urlfetch property
                method = {
                    "GET":urlfetch.GET,
                    "POST":urlfetch.POST,
                    "PUT":urlfetch.PUT,
                    "DELETE":urlfetch.DELETE
                }
                # executing request and returning response to caller
                return urlfetch.fetch(
                    url=self._target,
                    method=method[self.request_type],
                    headers=self._headers,
                    deadline=45,
                    payload=json.dumps(self.payload))
            except ImportError:
                # used for executing request outside of google app engine
                import requests
                # mapping method to urlfetch property
                method = {
                    "GET":requests.get,
                    "POST":requests.post,
                    "PUT":requests.put,
                    "DELETE":requests.delete
                }
                # executing request and returning response to caller
                return method[self.request_type](
                    headers=self._headers,
                    data=json.dumps(self.payload),
                    url=self._target,
                    timeout=45)

        except Exception as e:
            raise InvalidRequestError("INVALID REQUEST. An unkown general "
                "exception was raised. Error Message: {}".format(e))

    @classmethod
    def create_request(cls, **args):
        """Creating an http request.

        To create a request you must supply at a minimun, the follwoing items:
            - request_type
            - resource
            - resource_item

        Args:
            args(dict): a dictionary with the arguments provided for the
                        request.

        Returns:
            An http request object.
        """
        try:
            # required arguments. Raise exception if any of them are missing.
            request_type = args['request_type']
            resource = args['resource']
            resource_item = args['resource_item']
            # optional argument
            payload = args.get('payload')
            http_service = cls(request_type, payload) # constructing initial object
            http_service.set_resource(resource) # setting up resource
            http_service.set_resource_item(resource_item) # setting up resource item
            http_service.set_resource_headers() # setting up headers
            http_service.set_params(**dict()) # setting up parameters
            http_service.set_resource_target() # setting up resource target
            return http_service
        except KeyError as e:
            raise InvalidRequestError("INVALID REQUEST. "
                "{}".format(e))

class InvalidRequestTypeError(Exception):
    """Exception raised for errors in the input.

    Attributes:
        message -- explanation of the error
    """
    pass


class InvalidRequestError(Exception):
    """Raised when an invalid request is tried to be constructed.

    An example would be if the POST request is missing a payload.

    Attributes:
        message -- explanation of the error
    """
    pass
