from setuptools import setup

setup(name='http_services',
      version='1.0.1',
      description='An http service module that will prepare and execute http requests.',
      url='http://github.com/jeury301',
      author='Jeury Mejia',
      author_email='jeurymejia@nypl.org',
      license='NYPL',
      packages=['http_services'],
      install_requires=['requests'],
      zip_safe=False)
