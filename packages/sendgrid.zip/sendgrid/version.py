version_info = (3, 2, 10)
__version__ = '.'.join(str(v) for v in version_info)
